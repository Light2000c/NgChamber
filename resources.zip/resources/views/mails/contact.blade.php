
@component("mail::message")


Sender Name:  {{ $details['fullname'] }}

Sender Email:  {{ $details['email'] }}

Message: {{ $details['message'] }}



@endcomponent
    
